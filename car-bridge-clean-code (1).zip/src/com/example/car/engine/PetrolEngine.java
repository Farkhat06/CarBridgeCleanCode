package com.example.car.engine;

public class PetrolEngine implements Engine {
    @Override
    public void start() {
        System.out.println("Starting Petrol Engine...");
    }
}
