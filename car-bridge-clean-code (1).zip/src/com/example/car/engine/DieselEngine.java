package com.example.car.engine;

public class DieselEngine implements Engine {
    @Override
    public void start() {
        System.out.println("Starting Diesel Engine...");
    }
}
