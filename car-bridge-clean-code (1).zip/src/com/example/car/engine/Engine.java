package com.example.car.engine;

// Implementor interface
public interface Engine {
    void start();
}
